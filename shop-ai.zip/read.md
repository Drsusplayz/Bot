//npm i discord.js
//npm i dotenv
//npm i axios
//npm i images-scraper

FILL IN EVERY VARIABLE WITHIN THE .ENV

Fill in the handle commands file with your client ID:

Get your bard token by heading to https://rapidapi.com/nishantapps55/api/google-bard1/ and looking in the code snippets area. Be sure to subscribe to the free plan!  
Get your bard psid by watching https://youtu.be/vW-mzHO8fJs?si=DWN6aBYAnpSZFn9B&t=136 (its already set to the psid timestamp).  BE SURE TO LOGIN TO GOOGLE ON GOOGLE BARD, USE EDGE BROWSER. 

IF YOU NEED FURTHER GUIDE SETTING THIS UP, USE https://youtu.be/OgIfnYDa5_Q  

If you need help, use a help channel.