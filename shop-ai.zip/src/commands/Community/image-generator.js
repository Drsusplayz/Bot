const { SlashCommandBuilder, EmbedBuilder, AttachmentBuilder } = require('discord.js');
const Scraper = require('images-scraper');

module.exports = {
    data: new SlashCommandBuilder()
    .setName('image-generator')
    .setDescription('Remove an images background!')
    .addStringOption(option => option.setName('query').setDescription('The image to generate!').setRequired(true)),
    async execute (interaction) {

        await interaction.deferReply({ ephemeral: true });

        const { options } = interaction;
        const query = options.getString('query');

        const google = new Scraper({
            puppeteer: {
              headless: true,
            },
        });
        
        const results = await google.scrape(query, 200);
        const randomIndex = Math.floor(Math.random() * results.length);

        const embed = new EmbedBuilder()
        .setColor("Blurple")
        .setImage(results[randomIndex]?.url);

        await interaction.editReply({ embeds: [embed] }); 
    
    }
}