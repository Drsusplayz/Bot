const { Client, GatewayIntentBits, ActivityType, EmbedBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, Events, Partials, ChannelType, PermissionsBitField, Permissions, MessageManager, Embed, Collection, ButtonBuilder, ActionRowBuilder, ButtonStyle, DefaultDeviceProperty } = require(`discord.js`);
const fs = require('fs');
const internal = require('stream');
const client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMembers, GatewayIntentBits.GuildMessages, GatewayIntentBits.DirectMessageTyping, GatewayIntentBits.DirectMessages, GatewayIntentBits.MessageContent, GatewayIntentBits.GuildPresences], partials: [Partials.Message, Partials.Channel, Partials.Reaction] }); 

client.commands = new Collection();

require('dotenv').config();

const functions = fs.readdirSync("./src/functions").filter(file => file.endsWith(".js"));
const eventFiles = fs.readdirSync("./src/events").filter(file => file.endsWith(".js"));
const commandFolders = fs.readdirSync("./src/commands");

(async () => {
    for (file of functions) {
        require(`./functions/${file}`)(client);
    }
    client.handleEvents(eventFiles, "./src/events");
    client.handleCommands(commandFolders, "./src/commands");
    client.login(process.env.token)
})();

process.on('unhandledRejection', (reason, promise) => {
    console.log('Unhandled Rejection at:', promise, 'reason:', reason);
});

process.on("uncaughtException", (err) => {
    console.log("Uncaught Exception:", err);
});

process.on("uncaughtExceptionMonitor", (err, origin) => {
    console.log("Uncaught Exception Monitor", err, origin);
});

//chat logic
const axios = require('axios');
client.on(Events.MessageCreate, async message => {

    if (message.channel.type === ChannelType.DM) {
        if (message.author.bot) return;

        await message.channel.sendTyping();

        let input = {
            method: 'GET',
            url: 'https://bardgoogle.vercel.app/',
            headers: {
              text: message.content,
              lang: 'en',
              psid: process.env.bardPsid,
              'X-RapidAPI-Key': process.env.bardToken,
              'X-RapidAPI-Host': 'google-bard1.p.rapidapi.com'
            }
        };

        try {
            const output = await axios.request(input);
            const response = output.data.response;

            if (response.length > 2000) {
                const chunks = response.match(/.{1,2000}/g);

                for (let i = 0; i < chunks.length; i++) {
                    await message.author.send(chunks[i]).catch(err => {
                        message.author.send("I am having a hard time finding that request! Because I am an AI on discord, I don't have time to process long requests").catch(err => {});
                    });
                } 
            } else {
                await message.author.send(response).catch(err => {
                    message.author.send("I am having a hard time finding that request! Because I am an AI on discord, I don't have time to process long requests").catch(err => {});
                });
            }
        } catch (e) {
            console.log(e);
            message.author.send("I am having a hard time finding that request! Because I am an AI on discord, I don't have time to process long requests").catch(err => {});
        }
    } else {
        return;
    }

});
